import util, random
import numpy as np
from collections import defaultdict


def default():
  return util.Counter()
class Agent:

  def getAction(self, state):
    """
    For the given state, get the agent's chosen
    action.  The agent knows the legal actions
    """
    abstract

  def getValue(self, state):
    """
    Get the value of the state.
    """
    abstract

  def getQValue(self, state, action):
    """
    Get the q-value of the state action pair.
    """
    abstract

  def getPolicy(self, state):
    """
    Get the policy recommendation for the state.

    May or may not be the same as "getAction".
    """
    abstract

  def update(self, state, action, nextState, reward):
    """
    Update the internal state of a learning agent
    according to the (state, action, nextState)
    transistion and the given reward.
    """
    abstract


class RandomAgent(Agent):
  """
  Clueless random agent, used only for testing.
  """

  def __init__(self, actionFunction):
    self.actionFunction = actionFunction

  def getAction(self, state):
    return random.choice(self.actionFunction(state))

  def getValue(self, state):
    return 0.0

  def getQValue(self, state, action):
    return 0.0

  def getPolicy(self, state):
    return 'random'

  def update(self, state, action, nextState, reward):
    pass


################################################################################
# Exercise B - complete the ValueIterationAgent.

class ValueIterationAgent(Agent):

  def __init__(self, mdp, discount = 0.9, iterations = 100):
    """
    Your value iteration agent should take an mdp on
    construction, run the indicated number of iterations
    and then act according to the resulting policy.
    """
    self.mdp = mdp
    self.discount = discount
    self.iterations = iterations

    self.state_values = util.Counter()
    self.q_table_val = defaultdict(default)

    for i in range(iterations):
      new_state_values = util.Counter()
      for st in mdp.getStates():

        v= util.Counter()
        for ac in mdp.getPossibleActions(st):
          v[ac] = sum(prob * (mdp.getReward(st, ac, None) + discount * self.state_values.getCount(next_st)) for next_st, prob in
                       mdp.getTransitionStatesAndProbs(st, ac))
          self.q_table_val[st][ac] = v[ac]
        new_state_values[st] = v[v.argMax()] if mdp.getPossibleActions(st) else 0

      self.state_values = new_state_values   # self.state_values updated
    # Exercise B: program value iteration here.

    #raise ValueError("Exercise B code should replace this message.")

  def getValue(self, state):
    """
    Look up the value of the state (after the indicated
    number of value iteration passes).
    """
    # Exercise B: return the determined value for state
    #raise ValueError("Exercise B code should replace this message.")
    return self.state_values.getCount(state)

  def getQValue(self, state, action):
    """
    Look up the q-value of the state action pair
    (after the indicated number of value iteration
    passes).  Note that value iteration does not
    necessarily create this quantity and you may have
    to derive it on the fly.
    """
    # Exercise B: return the determined Q value state here (or compute it right here)
    #raise ValueError("Exercise B code should replace this message.")
    return self.q_table_val[state][action]

  def getPolicy(self, state):
    """
    Look up the policy's recommendation for the state
    using the mdp and the computed state values or Q values.
    """
    # Exercise B: return the best action here according to the Q or V values available
    #raise ValueError("Exercise B code should replace this message.")
    q_vals = self.q_table_val[state]
    return q_vals.argMax() if q_vals else 0

  def getAction(self, state):
    """
    Return the action recommended by the policy.
    """
    return self.getPolicy(state)


  def update(self, state, action, nextState, reward):
    """
    Not used for value iteration agents!
    """
    pass

################################################################################
# Policy iteration
# Exercise C - implement a policy iteration class here (similar to Value iteration)
class PolicyIterationAgent(Agent):
  def __init__(self, mdp, discount = 0.9, iterations = 100):
    """
    Your policy iteration agent should take an mdp on
    construction, run the indicated number of iterations
    and then act according to the resulting policy.
    """
    self.mdp = mdp
    self.discount = discount
    self.iterations = iterations

    self.state_values = util.Counter()
    self.q_table_val = defaultdict(default)
    self.policy={}

    for st in mdp.getStates():
      ac = mdp.getPossibleActions(st)
      if ac:
        self.policy[st] = random.choice(ac)

    for i in range(iterations):
      # new_values = util.Counter()

      for _ in range(10):
        for st in mdp.getStates():
          if not mdp.isTerminal(st):

            self.state_values[st] = sum(prob * (mdp.getReward(st, self.policy[st], None) + discount * self.state_values.getCount(next_st)) for next_st, prob in
            mdp.getTransitionStatesAndProbs(st, self.policy[st]))
            self.q_table_val[st][self.policy[st]] = self.state_values[st]



      for st in mdp.getStates():
        if not mdp.isTerminal(st):
          q = util.Counter()
          for ac in mdp.getPossibleActions(st):
            q[ac] = sum(prob * (mdp.getReward(st, ac, None) + discount * self.state_values.getCount(next_st)) for next_st, prob in
                         mdp.getTransitionStatesAndProbs(st, ac))
            self.q_table_val[st][ac] = q[ac]
          self.policy[st] = self.q_table_val[st].argMax()

  def getValue(self, state):
    """
  after the indicated
    number of value iteration passes.
    """
    # Exercise B: return the determined value for state
    return self.state_values.getCount(state)
    # raise ValueError("Exercise B code should replace this message.")

  def getQValue(self, state, action):
    """
    after the indicated number of value iteration
    passes
    """
    # Exercise B: return the determined Q value state here (or compute it right here)
    # raise ValueError("Exercise B code should replace this message.")
    return self.q_table_val[state][action]

  def getPolicy(self, state):
    """
    Look up the policy's recommendation for the state
    using the mdp and the computed state values or Q values.
    """
    # Exercise B: return the best action here according to the Q or V values available
    # raise ValueError("Exercise B code should replace this message.")
    if self.mdp.isTerminal(state):
      return None
    return self.policy[state]

  def getAction(self, state):
    """
    Return the action recommended by the policy.
    """
    return self.getPolicy(state)

  def update(self, state, action, nextState, reward):
    """
    Not used for value iteration agents!
    """
    pass