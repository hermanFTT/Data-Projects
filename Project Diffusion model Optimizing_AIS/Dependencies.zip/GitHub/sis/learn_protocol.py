import torch
from sis.sample import sample
import torch.optim as optim

from tqdm import tqdm

def learn_protocol(f_0, protocol, forward_kernel, weight_calculator, n_samples, n_steps, n_epochs, lr = 0.1):
    optimizer = optim.Adam(protocol.parameters(), lr=lr)

    pbar = tqdm(range(n_epochs))
    for epoch in pbar:
        weight_calculator.reset()
        _ = sample(f_0, protocol, forward_kernel, weight_calculator, n_samples, n_steps)

        total_weights = weight_calculator.total_weights_per_sample()
        
        # loss = -total_weights.mean()
        loss = torch.exp(-2 * total_weights).mean()
        
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(protocol.parameters(), 0.5)
        optimizer.step()
        pbar.set_description(f'Z:{torch.exp(total_weights).mean().item():.02f}, loss:{torch.exp(-2 * total_weights).mean().item():.02f}')

        # if epoch % 10 == 0:
        #     plot_beta(protocol)