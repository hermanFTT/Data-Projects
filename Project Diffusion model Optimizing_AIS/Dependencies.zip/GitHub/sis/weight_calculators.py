import torch


class AISLogWeightsCalculator:
    def __init__(self):
        self.weight_history = []

    def calculate_weights(self, f_t, next_ft, samples):
        current_density = f_t(samples)
        previous_density = next_ft(samples)

        weight_update = current_density - previous_density
        self.weight_history.append(weight_update)

    def total_weights_per_sample(self):
        return torch.stack(self.weight_history).sum(dim=0)
    
    def reset(self):
        self.weight_history = []