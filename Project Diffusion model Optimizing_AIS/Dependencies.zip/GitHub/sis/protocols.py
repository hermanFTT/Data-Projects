from os import device_encoding
import torch
import torch.nn as nn

class InterpolationProtocol():
    def __init__(self, f_0, f_T, device='cpu'):
        super().__init__()
        self.f_0 = f_0
        self.f_T = f_T
        self.device = device 

    def get_beta_t(self, t):
        return t
    
    def __call__(self, t):
        t = torch.tensor(t, device=self.device)
        def H(x):
            beta_t = self.get_beta_t(t.repeat(x.shape[0], 1)).squeeze()
            init_cont = self.f_0(x)*(1-beta_t)
            final_cont = self.f_T(x)*(beta_t)
            tmp = init_cont + final_cont

            return tmp

        return H
    

class LearnableInterpolationProtocol(nn.Module):
    def __init__(self, f_0, f_T, device='cpu'):
        super(LearnableInterpolationProtocol, self).__init__()
        self.f_0 = f_0
        self.f_T = f_T
        self.devic = device

        self.beta_network = nn.Sequential(
            nn.Linear(1, 32),
            nn.ReLU(),
            nn.Linear(32, 32),
            nn.ReLU(),
            nn.Linear(32, 1)
        )

    def get_beta_t(self, t):
        return torch.sigmoid(self.beta_network(t))
    
    def __call__(self, t):
        if t < 0.0001:
            return self.f_0
        if t > 0.9999:
            return self.f_T
        
        def H(x):
            beta_t = self.get_beta_t(t.repeat(x.shape[0], 1)).squeeze()
            init_cont = self.f_0(x)*(1-beta_t)
            final_cont = self.f_T(x)*(beta_t)
            tmp = init_cont + final_cont

            return tmp

        return H


class LearnableProtocol(nn.Module):
    def __init__(self, f_0, f_T, EBM):
        super(LearnableProtocol, self).__init__()
        self.f_0 = f_0
        self.f_T = f_T

        self.EBM = EBM

    def __call__(self, t):
        if t < 0.0001:
            return self.f_0
        if t > 0.9999:
            return self.f_T
            
        def H(x):
            ebm_contribution = self.EBM(x, t)

            # if t < 0.5: # Interpolate between f_0 and EBM for 0 <= t < 0.5
            #     scaled_t = t / 0.5
            #     ebm_contribution = scaled_t * ebm_output
            # else: # Interpolate between EBM and f_T for 0.5 <= t <= 1
            #     scaled_t = (t - 0.5) / 0.5
            #     ebm_contribution = (1 - scaled_t) * ebm_output
            
            tmp = ebm_contribution + (1 - t) * self.f_0(x) + t * self.f_T(x)
            return tmp
        return H


class FullyLearnableProtocol(nn.Module):
    def __init__(self, f_0, f_T, EBM):
        super(FullyLearnableProtocol, self).__init__()
        self.f_0 = f_0
        self.f_T = f_T

        self.EBM = EBM

    def __call__(self, t):
        if t < 0.0001:
            return self.f_0
        if t > 0.9999:
            return self.f_T

        def H(x):
            ebm_output = self.EBM(x, t)
            return ebm_output
            
        return H
