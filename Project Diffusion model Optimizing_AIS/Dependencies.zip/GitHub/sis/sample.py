import torch

def sample(f_0, protocol, kernel, weights_calculator, n_samples, n_steps):
    # Get initial samples 
    x_t = f_0.sample(n_samples) # We assume we can always sample from the initial distribution

    # Setup bookkeeping 
    samples_history = torch.zeros(n_steps+1, x_t.shape[0], x_t.shape[1], device=x_t.device)
    samples_history[0] = x_t.clone()

    # Determine timesteps
    ts = torch.linspace(0, 1, steps=n_steps + 1, device=x_t.device)

    # Get current hamiltonian
    f_t = protocol(ts[0])

    # Perform fist update to the protocol
    next_f_t = protocol(ts[1])
    weights_calculator.calculate_weights(f_t, next_f_t, x_t)
    f_t = next_f_t

    x_t.requires_grad = True
    for i in range(1, n_steps):
        # Perform sampling step
        next_x_t = kernel(x_t, f_t)

        # Update the protocol
        next_f_t = protocol(ts[i+1])
        
        # Perform bookkeeping
        samples_history[i+1] = next_x_t
        weights_calculator.calculate_weights(f_t, next_f_t, x_t)

        # Setup for next iteration
        x_t = next_x_t
        f_t = next_f_t

    return samples_history