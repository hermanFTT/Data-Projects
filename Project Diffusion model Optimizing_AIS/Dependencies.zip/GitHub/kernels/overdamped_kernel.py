from kernels.base_kernel import BaseKernel
from torch.distributions import MultivariateNormal
import torch


class OverdampedKernel(BaseKernel):
    def __init__(self, beta, step_size, device):
        self.step_size = torch.tensor(step_size)
        self.beta = beta
        self.device = device
        self.W = MultivariateNormal(torch.zeros(2, device=device), torch.eye(2, device=device))

    def K(self, x, f):
        log_density = self.beta * f(x)
        grad_log_density = torch.autograd.grad(log_density.sum(), x, retain_graph=True, create_graph=True)[0]
    
        # Langevin update
        x_new = x - self.step_size * grad_log_density + torch.sqrt(2 * self.beta*self.step_size) * self.W.rsample((x.shape[0],))
        return x_new 