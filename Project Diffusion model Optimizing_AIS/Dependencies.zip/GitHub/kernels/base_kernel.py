from abc import abstractmethod


class BaseKernel():
    def __init__(self):
        pass

    @abstractmethod
    def K(self, x, f):
        pass

    def __call__(self, x, f):
        return self.K(x, f)