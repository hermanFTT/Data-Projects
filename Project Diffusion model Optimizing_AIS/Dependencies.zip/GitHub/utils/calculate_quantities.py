def calculate_quantities(weights_calculator):
    total_work_per_particle = weights_calculator.total_weights_per_sample()

    average_work = total_work_per_particle.mean().item()
    variance_work = total_work_per_particle.var().item()

    exp_total_work_per_particle = total_work_per_particle.exp()
    normalizing_constant_estimate = exp_total_work_per_particle.mean().item()
    variance_normalizing_constant = exp_total_work_per_particle.var().item()

    print(f"Average Work: {average_work:.2f}")
    print(f"Variance of Work: {variance_work:.2f}")
    print(f"Normalizing Constant Estimate: {normalizing_constant_estimate:.2f}")
    print(f"Variance of Normalizing Constant Estimate: {variance_normalizing_constant:.2f}")