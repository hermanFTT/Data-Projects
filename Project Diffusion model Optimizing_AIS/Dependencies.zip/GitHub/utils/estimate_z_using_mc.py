import torch

def estimate_z_using_mc(f, beta, lower_bounds, upper_bounds, samples=100000, device='cpu'):
    lower_bounds = torch.tensor(lower_bounds, dtype=torch.float32, device=device)
    upper_bounds = torch.tensor(upper_bounds, dtype=torch.float32, device=device)
    
    # Generate random samples within the given bounds
    dims = len(lower_bounds)
    points = torch.rand(samples, dims, device=device) * (upper_bounds - lower_bounds) + lower_bounds
    
    # Evaluate the function at these points
    values = torch.exp(-beta * f(points))
    
    # Compute the average value
    avg_value = torch.mean(values)
    volume = torch.prod(upper_bounds - lower_bounds)
    
    # Approximate the integral
    Z = avg_value * volume
    
    return Z.item()