import torch
import numpy as np 
import matplotlib.pyplot as plt

from matplotlib.animation import FuncAnimation
from IPython.display import HTML


def plot_protocol(protocol, beta, device='cpu'):
    x = np.linspace(-5, 5, 100)
    y = np.linspace(-5, 5, 100)
    X, Y = np.meshgrid(x, y)
    xy = np.dstack([X, Y])
    xy_torch = torch.tensor(xy, dtype=torch.float32, device=device).view(100 * 100, -1)

    # Pre-computation for global color scale
    times = torch.linspace(0, 1, 10, device=device)
    global_min, global_max = float('inf'), float('-inf')
    for t in times:
        f_t = protocol(t)
        density = -beta * f_t(xy_torch).detach().cpu().numpy()
        density = density.reshape(100, 100)
        global_min = min(global_min, density.min())
        global_max = max(global_max, density.max())

    # Plot setup
    fig, axs = plt.subplots(2, 5, figsize=(25, 10))  # Adjusted figsize to give more space
    cmap = 'viridis'

    for ax, t in zip(axs.ravel(), times):
        f_t = protocol(t)

        density = -beta * f_t(xy_torch).detach().cpu().numpy()
        density = density.reshape(100, 100)

        # Apply global color scale
        c = ax.contourf(X, Y, density, levels=50, cmap=cmap, vmin=global_min, vmax=global_max)
        ax.set_title(f'time = {t:.2f}')
        ax.set_aspect('equal')

    plt.subplots_adjust(wspace=0.4, hspace=0.4)

    plt.show()

def plot_animation(protocol, samples_history=None, device='cpu'):
    frames = 100  # Assuming 100 steps in samples_history for simplicity

    # Grid setup
    x = np.linspace(-5, 5, 100)
    y = np.linspace(-5, 5, 100)
    X, Y = np.meshgrid(x, y)
    xy = np.dstack([X, Y])

    # Create figure and axis
    fig, ax = plt.subplots(figsize=(8, 8))
    cmap = 'viridis'  # Defining the colormap to use

    # Precompute global min and max for consistent color scale
    global_min, global_max = float('inf'), float('-inf')
    for t in np.linspace(0, 1, frames):
        f_t = protocol(torch.tensor(t, dtype=torch.float32, device=device))
        xy_torch = torch.tensor(xy, dtype=torch.float32, device=device).view(-1, 2)
        density = -f_t(xy_torch).detach().cpu().numpy().reshape(100, 100)
        global_min = min(global_min, density.min())
        global_max = max(global_max, density.max())

    # Initialize the plot with the first frame
    t0 = torch.tensor(0, dtype=torch.float32, device=device)
    f_t = protocol(t0)
    xy_torch = torch.tensor(xy, dtype=torch.float32, device=device)
    original_shape = xy_torch.shape
    density = -f_t(xy_torch.view(-1, 2)).detach().cpu().numpy()
    density = density.reshape(original_shape[0], original_shape[1])

    contour = [ax.contourf(X, Y, density, levels=50, cmap=cmap, vmin=global_min, vmax=global_max)]
    ax.set_aspect('equal')
    ax.set_xlim(-5, 5)
    ax.set_ylim(-5, 5)

    def update(frame):
        t = torch.tensor(np.linspace(0, 1, frames)[frame], dtype=torch.float32, device=device)
        f_t = protocol(t)
        xy_torch = torch.tensor(xy, dtype=torch.float32, device=device)
        density = -f_t(xy_torch.view(-1, 2)).detach().cpu().numpy().reshape(100, 100)

        for c in contour[0].collections:
            c.remove()
        contour[0] = ax.contourf(X, Y, density, levels=50, cmap=cmap, vmin=global_min, vmax=global_max)
        ax.set_title(f'Time = {t.item():.2f}')

        # Handle samples_history if provided
        if samples_history is not None:
            samples = samples_history[frame].cpu().detach()
            ax.scatter(samples[:100, 0], samples[:100, 1], color='white', s=5, edgecolors='black')

        return contour[0].collections

    anim = FuncAnimation(fig, update, frames=frames, interval=100, blit=True)
    plt.close(fig)  # Prevents duplicate display
    return HTML(anim.to_jshtml())

def plot_beta(protocol, device='cpu'):
    t_values = torch.linspace(0, 1, 100, device=device).view(-1, 1)
    # Calculate beta for each t value
    beta_values = [protocol.get_beta_t(torch.tensor([[t]], dtype=torch.float, device=device)).cpu().item() for t in t_values]
    
    # Plotting
    plt.figure(figsize=(10, 6))
    plt.plot(t_values.cpu(), beta_values, label=r'$\beta(t)$')
    plt.ylim(0, 1)
    plt.xlabel('t')
    plt.ylabel(r'$\beta(t)$')
    plt.title('Plot of Beta over the Range 0 to 1')
    plt.legend()
    plt.show()

def plot_f_T(f_t, a, b, steps=50, device='cpu'):
    x = np.linspace(a, b, steps)
    y = np.linspace(a, b, steps)
    X, Y = np.meshgrid(x, y)
    # We combine X and Y for input to f_T
    xy = np.dstack([X, Y])
    xy_torch = torch.tensor(xy, dtype=torch.float32, device=device)
    density = -f_t(xy_torch).cpu().numpy()
    
    fig = plt.figure(figsize=(12, 8))
    ax = fig.add_subplot(111)
    ax.contourf(X, Y, density, levels=50, cmap='viridis')#, norm=norm)
    ax.set_aspect('equal')
    ax.set_xlabel('X axis')
    ax.set_ylabel('Y axis')
    ax.set_title('Surface plot of f_T(x) over a given range')
    plt.show()