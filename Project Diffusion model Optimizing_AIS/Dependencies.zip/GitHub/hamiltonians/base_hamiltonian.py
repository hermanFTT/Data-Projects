from abc import abstractmethod


class BaseHamiltonian():
    def __init__(self):
        self.is_normalized = False

    @abstractmethod
    def H(self, x):
        pass

    def __call__(self, x):
        return self.H(x)
    

class BaseTimedHamiltonian(BaseHamiltonian):
    def __init__(self):
        super().__init__()

    @abstractmethod
    def H(self, x, t):
        pass

    def __call__(self, x, t):
        return self.H(x, t)