from hamiltonians.base_hamiltonian import BaseHamiltonian, BaseTimedHamiltonian
import torch


class HarmonicPotential(BaseHamiltonian):
    def __init__(self, mean=None):
        self.mean = mean

    def H(self, x):
        tmp = 0.5 * ((x - self.mean) ** 2).sum(dim=-1)
        return tmp

class NormalisedHarmonicPotential(BaseHamiltonian):
    def __init__(self, mean=None, std=None):
        super().__init__()
        if std is None:
            std = torch.eye(2)
        if mean is None:
            mean = torch.tensor([0.0, 0.0])
        self.std = std
        self.mean = mean

        self.p_0 = torch.distributions.MultivariateNormal(mean, std)

        self.is_normalized = True
        self.sampleable = True

    def H(self, x):
        return -self.p_0.log_prob(x) # Has Z = 1
    
    def sample(self, n_samples):
        return self.p_0.sample((n_samples,))

class NormalisedHarmonicPotential(BaseHamiltonian):
    def __init__(self, mean=None, std=None):
        super().__init__()
        if std is None:
            std = torch.eye(2)
        if mean is None:
            mean = torch.tensor([0.0, 0.0])
        self.std = std
        self.mean = mean

        self.p_0 = torch.distributions.MultivariateNormal(mean, std)

        self.is_normalized = True
        self.sampleable = True

    def H(self, x):
        return -self.p_0.log_prob(x) # Has Z = 1
    
    def sample(self, n_samples):
        return self.p_0.sample((n_samples,))

  
class GMMPotential(BaseHamiltonian):
    def __init__(self, device='cpu'):
        super().__init__()
        self.device = device
        n_gaussians = 10  # Number of GMM mixture components

        # Generate parameters for GMM components
        means = torch.rand(n_gaussians, 2, device=self.device) * 10 - 5  # Uniformly distributed in [-5, 5]
        stds = torch.rand(n_gaussians, 2, device=self.device) * 1 + 0.5  # Uniformly distributed in [0.5, 1.5]

        mixture_weights = torch.ones(n_gaussians, device=self.device) / n_gaussians  # Equal weights for simplicity
        mixture_distribution = torch.distributions.Categorical(mixture_weights)
        component_distribution = torch.distributions.Independent(torch.distributions.Normal(means, stds), 1)
        self.p_0 = torch.distributions.MixtureSameFamily(mixture_distribution, component_distribution)

        self.is_normalized = True
        self.sampleable = True

    def H(self, x):
        return -self.p_0.log_prob(x) # Has Z = 1
    
    def sample(self, n_samples):
        return self.p_0.sample((n_samples,))


class DifficultGMMPotential(BaseHamiltonian):
    def __init__(self, device='cpu'):
        super().__init__()
        self.device = device

        # Generate parameters for GMM components
        means = torch.tensor([[0., 0.], [-4., -4.], [-4., 4.], [4., 4.], [4., -4.]], device=device)
        stds = torch.tensor([[1., 1.], [.1, .1], [.1, .1], [.1, .1], [.1, .1]], device=device)

        mixture_weights = torch.ones(5, device=self.device) / 5  # Equal weights for simplicity
        mixture_distribution = torch.distributions.Categorical(mixture_weights)
        component_distribution = torch.distributions.Independent(torch.distributions.Normal(means, stds), 1)
        self.p_0 = torch.distributions.MixtureSameFamily(mixture_distribution, component_distribution)

        self.is_normalized = True
        self.sampleable = True

    def H(self, x):
        return -self.p_0.log_prob(x) # Has Z = 1
    
    def sample(self, n_samples):
        return self.p_0.sample((n_samples,))


      